@echo off
powershell.exe -NoProfile -File "%~dp0MPC-Method-Self-Scan.ps1" %*
if errorlevel 1 pause
