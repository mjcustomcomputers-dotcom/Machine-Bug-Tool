$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'MPC-Method-Self-Scan-e3a8f15\Run-Method-Self-Scan.ps1') @args
