@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "MPC_APP=%~dp0MPC-Method-Lab.html"
if not exist "%MPC_APP%" (
 echo ERROR: MPC-Method-Lab.html is missing.
 echo Press any key to close this window . . .
 pause >nul
 exit /b 1
)
start "" "%MPC_APP%"
if errorlevel 1 (
 echo ERROR: The default browser could not open MPC Method Lab.
 echo Press any key to close this window . . .
 pause >nul
 exit /b 1
)
endlocal
