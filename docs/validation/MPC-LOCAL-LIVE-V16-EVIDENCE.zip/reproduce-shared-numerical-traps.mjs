import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {evaluateMethod,getMethodCatalog} from '../Machine-Bug-Tool-Reasoning/lib/methods.mjs';
const root='/workspace/scratch/479911d33054/Machine-Bug-Tool-Reasoning';
const output='/workspace/scratch/479911d33054/local-live-v16-evidence/native-shared-numerical-traps.json';
const input={row_payoffs:[[1-2**-52,2**-54],[1,-(2**-54)]],column_payoffs:[[0,1],[1,0]]};
const shifted={row_payoffs:[[-(2**-52),2**-54],[0,-(2**-54)]],column_payoffs:input.column_payoffs};
const originalReceipt=await evaluateMethod({method:'nash',input});
const shiftedReceipt=await evaluateMethod({method:'nash',input:shifted});
const q=originalReceipt.result.strict_interior_mixed.column_probabilities;
const indifferenceInput={states:q.map((probability,i)=>({id:'c'+i,probability})),actions:input.row_payoffs.map((payoffs,i)=>({id:'r'+i,payoffs}))};
const indifferenceReceipt=await evaluateMethod({method:'harsanyi',input:indifferenceInput});
const conservationInput={unit:'SYNTHETIC_UTILITY',opening:1,inflows:[2**-54],outflows:[1],closing:0,tolerance:0};
const conservationReceipt=await evaluateMethod({method:'conservation',input:conservationInput});
const linearInput={states:[{id:'opening',probability:0.5},{id:'inflow',probability:0.25},{id:'outflow',probability:0.25}],actions:[{id:'equivalent-expression',payoffs:[2,2**-52,-4]}]};
const linearReceipt=await evaluateMethod({method:'harsanyi',input:linearInput});
const report={kind:'READ_ONLY_SHARED_NATIVE_NUMERICAL_FALSIFIERS',recorded_at_utc:new Date().toISOString(),
 source:{repository:'mjcustomcomputers-dotcom/Machine-Bug-Tool',local_path:root,head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),dirty:execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim()!=='',files:Object.fromEntries(['lib/methods.mjs','lib/atomic-models.mjs','lib/forensic-models.mjs','lib/deferred-models.mjs','lib/schema.mjs','lib/universal.mjs'].map(path=>[path,createHash('sha256').update(readFileSync(root+'/'+path)).digest('hex')]))},
 native_catalog:{version:getMethodCatalog().version,registered_methods:getMethodCatalog().methods},
 counts:{registry_methods_reviewed:24,distinct_native_methods_executed:3,native_calls_in_this_reproducer:5,independent_cross_method_traps:2},
 traps:[
  {id:'NASH_COLUMN_TRANSLATION_CONDITIONING',classification:'SHARED_NUMERICAL_LIMITATION_WITH_UNSIGNALLED_CONDITIONING',
   input,raw_native_receipt:originalReceipt,negative_control:{transformation:'Subtract constant1 from both row-player payoffs in the first column only. This preserves every row-player best response.',input:shifted,raw_native_receipt:shiftedReceipt},
   cross_method:{method:'harsanyi',input:indifferenceInput,raw_native_receipt:indifferenceReceipt},
   independent_expected:{row_probability:'1/2',column_probability:'1/3',derivation:'Row payoff difference is -q*2^-52 + (1-q)*2^-53 = 0, hence q=1/3. Column indifference gives p=1/2.',native_probability_error:'Native q=0.4 differs from1/3 by about0.0666666666666667; exact fractions are supplied by independent Python review.',expected_harsanyi_maximizer_at_native_q:['r1']},
   limitation_explains:'Nash explicitly uses approximate IEEE754 mixed probabilities; Harsanyi performs ordinary floating accumulation. This explains the shared susceptibility, but neither returned receipt warns of failed indifference or conditioning. No source-authenticated or target finding is implied.'},
  {id:'CONSERVATION_ZERO_TOLERANCE_ROUNDING',classification:'SHARED_NUMERICAL_FALSE_PASS_WITH_UNSIGNALLED_PRECISION_LOSS',
   input:conservationInput,raw_native_receipt:conservationReceipt,cross_method:{method:'harsanyi',input:linearInput,raw_native_receipt:linearReceipt},
   independent_expected:{expected_closing:'1/18014398509481984',residual:'-1/18014398509481984',within_supplied_tolerance:false,derivation:'Exact1 + 2^-54 -1 =2^-54. A zero declared tolerance cannot include residual-2^-54.',harsanyi_value:'1/18014398509481984'},
   limitation_explains:'Both implementations round the small middle contribution away while adding it to1. Native conservation exposes no exact-arithmetic or rounding-error receipt; both still correctly deny causation/source authentication.'}
 ],
 boundaries:{synthetic_inputs_only:true,hosted_calls_performed_here:false,source_edits:false,source_authentication:false,target_finding:false,catalog_or_registry_mutation:false}};
writeFileSync(output,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({output,head:report.source.head,native_calls:5,nash_q:q[0],shifted_q:shiftedReceipt.result.strict_interior_mixed.column_probabilities[0],native_indifference:indifferenceReceipt.result.maximizers,conservation_pass:conservationReceipt.result.within_supplied_tolerance,shared_linear_value:linearReceipt.result.values[0].expected_utility}));
