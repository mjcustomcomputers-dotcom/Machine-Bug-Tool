import {readFileSync, writeFileSync, existsSync, mkdirSync} from 'node:fs';
import {resolve, dirname} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';

// Evidence-only harness. It imports the preserved native V15 implementation,
// performs no network operation, and never writes into the source checkout.
const HERE = dirname(fileURLToPath(import.meta.url));
const REPO = resolve(HERE, '../Machine-Bug-Tool-Reasoning');
const OUTPUT = process.argv[2] ? resolve(process.argv[2]) : HERE;
const NUMERICAL_FILE = resolve(HERE, 'native-numerical-four-cases.json');
const EXACT_ORACLE_FILE = resolve(HERE, 'native-shared-numerical-exact-oracle.json');
const {evaluateMethod, getMethodCatalog} = await import(pathToFileURL(resolve(REPO, 'lib/methods.mjs')));
const {canonical, digest} = await import(pathToFileURL(resolve(REPO, 'lib/universal.mjs')));
const {validate} = await import(pathToFileURL(resolve(REPO, 'lib/schema.mjs')));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const clone = value => JSON.parse(JSON.stringify(value));
const sourcePaths = [
  'lib/methods.mjs', 'lib/atomic-models.mjs', 'lib/forensic-models.mjs',
  'lib/deferred-models.mjs', 'lib/schema.mjs', 'lib/universal.mjs',
  'lib/atomic-source-pointers.json', 'lib/forensic-source-pointers.json',
  'lib/method-overlay.json'
];
const sourceFiles = () => sourcePaths.map(path => {
  const bytes = readFileSync(resolve(REPO, path));
  return {path, bytes: bytes.length, sha256: sha(bytes)};
});
const git = args => execFileSync('git', args, {cwd: REPO, encoding: 'utf8'}).trim();
const before = sourceFiles();
const sourceIdentity = {
  repository_path: REPO, local_git_head: git(['rev-parse', 'HEAD']),
  local_git_tree: git(['rev-parse', 'HEAD^{tree}']),
  working_tree_dirty: Boolean(git(['status', '--porcelain=v1'])),
  native_evaluator_files: before,
  native_evaluator_files_fingerprint: await digest(before),
  interpretation: 'Exact local bytes. Does not identify current deployed source or authenticate supplied model facts.'
};
const eq = (path, value) => ({path, op: 'EQUALS', value});
const record = (id, kind, amount) => ({id, kind, amount, source_ref: 'synthetic:event:' + id});
const field = (field, value) => ({field, value});
const sourceRow = (id, fields) => ({id, fields, source_ref: 'synthetic:row:' + id});
const cases = [];
function add(case_id, method, input, assertions, reasoning, pair, role = 'CONTROL') {
  cases.push({case_id, method, input,
    expectation: {outcome: 'RESULT', assertions, reasoning},
    comparison: {pair_id: pair, role}, synthetic_inputs_only: true});
}
function reject(case_id, method, input, error, reasoning, pair) {
  cases.push({case_id, method, input,
    expectation: {outcome: 'ERROR', error_message: error, reasoning},
    comparison: {pair_id: pair, role: 'NEGATIVE_CONTROL'}, synthetic_inputs_only: true});
}

const claw = {unit: 'SYNTHETIC_CREDITS', opening: 0, threshold: 3,
  events: [record('accrue', 'ACCRUE', 3), record('reset', 'RESET', 3), record('award', 'AWARD_RECORDED', 7)]};
add('claw_explicit_award_reset', 'claw_accumulator', claw,
  [eq('/result/closing_accumulator', 0), eq('/result/threshold_reached', false),
   eq('/result/trace/0/threshold_reached', true), eq('/result/recorded_award_units', 7),
   eq('/result/award_entitlement_inferred', false), eq('/result/reset_policy', 'EXPLICIT_RESET_ONLY')],
  'An award record is counted separately. Only the explicit reset reduces the accumulator; earlier threshold crossing does not imply entitlement.', 'claw_prefix');
reject('claw_reset_before_accrual', 'claw_accumulator', {...claw, events: [claw.events[1], claw.events[0], claw.events[2]]},
  'RESET_EXCEEDS_ACCUMULATOR', 'Reordering identical amounts creates an invalid prefix even though their final arithmetic sum is unchanged.', 'claw_prefix');

const coin = {unit: 'SYNTHETIC_TOKENS', opening_pending: 2,
  events: [record('deposit', 'DEPOSIT', 3), record('release', 'RELEASE', 4), record('remove', 'REMOVE', 1)]};
add('coin_deferred_balance', 'coin_pusher_deferred', coin,
  [eq('/result/pending', 0), eq('/result/released', 4), eq('/result/removed', 1),
   eq('/result/released_is_paid', false), eq('/result/current_depositor_owns_release', false)],
  'The independent integer balance is 2 + 3 - 4 - 1 = 0, with release and removal kept separate.', 'coin_prefix');
reject('coin_release_before_deposit', 'coin_pusher_deferred', {...coin, events: [coin.events[1], coin.events[0], coin.events[2]]},
  'OUTFLOW_EXCEEDS_PENDING', 'A release of four cannot occur from a supplied opening of two before the deposit.', 'coin_prefix');

const casino = {unit: 'SYNTHETIC_CENTS', records: [{id: 'meter', meter_amount: 10, finalized_amount: 10, paid_amount: 10,
  meter_ref: 'synthetic:meter', finality_ref: 'synthetic:finality', payment_ref: 'synthetic:payment'}]};
add('casino_equal_amounts_separate_states', 'casino_meter_finality', casino,
  [eq('/result/records/0/meter_minus_finalized', 0), eq('/result/records/0/finalized_minus_paid', 0),
   eq('/result/meter_proves_finality', false), eq('/result/equal_amounts_prove_same_state', false)],
  'Numerical equality does not collapse displayed, finalized and paid states or authenticate their references.', 'casino_payment_reference');
const casinoMissing = clone(casino); casinoMissing.records[0].payment_ref = '';
reject('casino_positive_payment_missing_reference', 'casino_meter_finality', casinoMissing,
  'PAYMENT_REFERENCE_REQUIRED', 'A positive supplied payment needs its own nonblank reference field.', 'casino_payment_reference');

const ledger = {accounts: [
  {id: 'a', unit: 'SYNTHETIC_USD_CENT', opening: 8, observed_closing: 5, source_ref: 'synthetic:a'},
  {id: 'b', unit: 'SYNTHETIC_USD_CENT', opening: 1, observed_closing: 4, source_ref: 'synthetic:b'}],
  transfers: [{id: 't', from: 'a', to: 'b', amount: 3, source_ref: 'synthetic:t'}]};
add('ledger_closed_integer_balance', 'ledger', ledger,
  [eq('/result/accounts/0/residual', 0), eq('/result/accounts/1/residual', 0),
   eq('/result/units/0/opening', 9), eq('/result/units/0/observed_closing', 9), eq('/result/mismatch_proves_loss', false)],
  'Independent per-account arithmetic is 8 - 3 = 5 and 1 + 3 = 4; the closed total stays nine.', 'ledger_unit');
const crossUnit = clone(ledger); crossUnit.accounts[1].unit = 'SYNTHETIC_EUR_CENT';
reject('ledger_currency_change_requires_conversion', 'ledger', crossUnit,
  'CROSS_UNIT_TRANSFER_REQUIRES_SEPARATE_CONVERSION_RECORDS', 'Changing only the destination unit invalidates the transfer without an explicit conversion model.', 'ledger_unit');

const relational = {rows: [sourceRow('r1', [field('parent', 'x'), field('key', 'a')]), sourceRow('r2', [field('parent', 'y')])],
  rules: [{id: 'fk', kind: 'FOREIGN_KEY', field: 'parent', other_field: 'key', source_ref: 'synthetic:fk'}]};
add('relational_missing_target_unknown', 'relational', relational,
  [eq('/result/rules/0/status', 'INCOMPLETE'), eq('/result/rules/0/unknown_row_ids', ['r1', 'r2']),
   eq('/result/rules/0/violations', []), eq('/result/global_completeness_proven', false)],
  'A missing target field can still contain either sought value. Both unresolved references remain unknown within this supplied table.', 'relational_completion');
const completeRelations = clone(relational); completeRelations.rows[1].fields.push(field('key', 'b'));
add('relational_completed_nonmatch', 'relational', completeRelations,
  [eq('/result/rules/0/status', 'MISMATCH_IN_SUPPLIED_ROWS'), eq('/result/rules/0/unknown_row_ids', []),
   eq('/result/rules/0/violations', [{row_ids: ['r1']}, {row_ids: ['r2']}])],
  'After the final missing target becomes b, the complete supplied target set {a,b} contains neither x nor y.', 'relational_completion', 'VARIANT');

const order = {events: ['a', 'b', 'c'].map(id => ({id, source_ref: 'synthetic:' + id})),
  precedes: [{before: 'a', after: 'b', source_ref: 'synthetic:a-before-b'}], observed_order: ['a', 'c', 'b']};
add('partial_order_unconstrained_middle', 'partial_order', order,
  [eq('/result/violations', []), eq('/result/unconstrained_pairs_are_concurrent', false)],
  'Only a before b is declared. The placement of c supplies no concurrency proof.', 'partial_unconstrained');
add('partial_order_unconstrained_first', 'partial_order', {...order, observed_order: ['c', 'a', 'b']},
  [eq('/result/violations', []), eq('/result/unconstrained_pairs_are_concurrent', false)],
  'Moving c preserves the only declared edge and should preserve conformance.', 'partial_unconstrained', 'VARIANT');

const metamorphic = {left: {id: 'left', controls: [field('channel', 'web'), field('subject', 'same')],
  observations: [field('receipt', ''), field('state', 'pending')], source_ref: 'synthetic:left'},
  right: {id: 'right', controls: [field('channel', 'api'), field('subject', 'same')],
  observations: [field('state', 'pending')], source_ref: 'synthetic:right'}, changed_control: 'channel'};
add('metamorphic_missing_versus_empty', 'metamorphic', metamorphic,
  [eq('/result/preserved_controls', ['subject']), eq('/result/observations/0/field', 'receipt'),
   eq('/result/observations/0/left', ''), eq('/result/observations/0/right', null),
   eq('/result/observations/0/state', 'MISSING_SIDE'), eq('/result/observations/1/state', 'EQUAL'),
   eq('/result/causation_established', false)],
  'Exactly one declared control changes. An explicit empty string remains distinct from an absent observation field.', 'metamorphic_control_count');
const twoControls = clone(metamorphic); twoControls.right.controls[1].value = 'different';
reject('metamorphic_second_control_changed', 'metamorphic', twoControls,
  'EXACTLY_ONE_DECLARED_CONTROL_CHANGE_REQUIRED', 'A second changed control defeats this declared single-control comparison.', 'metamorphic_control_count');

const temporal = {events: [{id: 'authorize', subject: 's', kind: 'authorize', time: 10, source_ref: 'synthetic:authorize'},
  {id: 'capture', subject: 's', kind: 'capture', time: 20, source_ref: 'synthetic:capture'}],
  rules: [{id: 'r', trigger: 'capture', required_prior: 'authorize', max_age_ms: 10, source_ref: 'synthetic:r'}],
  window_start: 0, window_end: 30};
add('temporal_exact_max_age_boundary', 'temporal', temporal,
  [eq('/result/checks/0/status', 'PRIOR_EVENT_PRESENT'), eq('/result/checks/0/prior_ids', ['authorize']),
   eq('/result/checks/0/left_censored', false), eq('/result/missing_means_violation', false)],
  'Age ten is included by the supplied bound of ten, and the prior timestamp is strictly earlier.', 'temporal_strict_prior');
const simultaneous = clone(temporal); simultaneous.events[0].time = 20;
add('temporal_equal_timestamp_not_prior', 'temporal', simultaneous,
  [eq('/result/checks/0/status', 'PRIOR_NOT_OBSERVED'), eq('/result/checks/0/prior_ids', []),
   eq('/result/missing_means_violation', false)],
  'Equal timestamps do not satisfy the strictly-earlier predicate. Missing prior evidence remains an observation boundary.', 'temporal_strict_prior', 'VARIANT');

const identityGraph = {nodes: [
  {id: 'a', namespace: 'synthetic', native_id: 'object-1', version: 'v1', owner: 'owner-1', label: 'old', source_ref: 'synthetic:a'},
  {id: 'b', namespace: 'synthetic', native_id: 'object-1', version: 'v2', owner: 'owner-1', label: 'new', source_ref: 'synthetic:b'}],
  links: [{from: 'a', to: 'b', kind: 'SAME_IDENTITY', source_ref: 'synthetic:link'}]};
add('identity_graph_version_and_label_separate', 'identity_graph', identityGraph,
  [eq('/result/links/0/status', 'DECLARED_NATIVE_KEY_MATCH'), eq('/result/links/0/version_match', false),
   eq('/result/links/0/label_match', false), eq('/result/aliases_automatically_merged', false)],
  'The native tuple matches while presentation and revision do not. The declaration does not authenticate or merge records.', 'identity_graph_owner');
const transferred = clone(identityGraph); transferred.nodes[1].owner = 'owner-2';
add('identity_graph_owner_change', 'identity_graph', transferred,
  [eq('/result/links/0/status', 'DECLARED_NATIVE_KEY_DIFFERENCE'), eq('/result/identity_authenticated', false)],
  'Ownership is part of the native comparison tuple even when the locator remains equal.', 'identity_graph_owner', 'VARIANT');

const authority = {rules: [], records: [{id: 'paid-display', actor: 'ui', subject: 's', action: 'capture', state: 'PAID', source_ref: 'synthetic:record'}], rule_set_complete: false};
add('authority_paid_state_does_not_fill_missing_rules', 'authority_graph', authority,
  [eq('/result/records/0/authority_status', 'UNKNOWN'), eq('/result/records/0/state', 'PAID'),
   eq('/result/authority_authenticated', false), eq('/result/rule_match_proves_execution', false)],
  'The record state cannot supply a missing authority rule. An incomplete empty rule set stays unresolved.', 'authority_completeness');
add('authority_declared_complete_absence', 'authority_graph', {...authority, rule_set_complete: true},
  [eq('/result/records/0/authority_status', 'NO_MATCH_IN_DECLARED_COMPLETE_RULE_SET'),
   eq('/result/rule_set_complete_is_caller_assertion', true), eq('/result/authority_authenticated', false)],
  'Only the caller completeness assertion changes; its effect is a scoped declared-rule absence, not authenticated lack of authority.', 'authority_completeness', 'VARIANT');

const proposition = {variables: ['P', 'Q'], nodes: [
  {id: 'P', op: 'VAR', variable: 'P'}, {id: 'Q', op: 'VAR', variable: 'Q'},
  {id: 'rule', op: 'IMPLIES', args: ['P', 'Q']}, {id: 'notQ', op: 'NOT', args: ['Q']}, {id: 'notP', op: 'NOT', args: ['P']}],
  assumptions: ['rule', 'notQ'], conclusion: 'notP'};
add('propositional_modus_tollens', 'propositional_entailment', proposition,
  [eq('/result/status', 'FINITE_ENTAILMENT'), eq('/result/entails', true), eq('/result/assignments_examined', 4),
   eq('/result/satisfying_assumption_assignments_examined', 1), eq('/result/vacuous', false)],
  'Of the four Boolean assignments, only P=false,Q=false satisfies both assumptions, and it satisfies not P.', 'propositional_budget');
add('propositional_partial_rows_do_not_prove', 'propositional_entailment', {...proposition, max_assignments: 2},
  [eq('/result/status', 'UNKNOWN_RESOURCE_LIMIT'), eq('/result/entails', null), eq('/result/enumeration_complete', false),
   eq('/result/assignments_examined', 2)],
  'Successful examined rows cannot replace the two unexamined assignments required by this evaluator contract.', 'propositional_budget', 'VARIANT');

const invariant = {invariant_label: 'SYNTHETIC_SAFE', states: [
  {id: 'S', invariant_holds: true}, {id: 'U', invariant_holds: true}, {id: 'B', invariant_holds: false}],
  initial_states: ['S'], transitions: [{id: 'u-b', from: 'U', to: 'B'}], forbidden_states: []};
add('invariant_unreachable_step_failure', 'finite_invariant', invariant,
  [eq('/result/status', 'FINITE_GRAPH_VERIFIED'), eq('/result/reachable_predicate_holds', true), eq('/result/counterexample', null),
   eq('/result/induction_obligations/step/status', 'FAIL')],
  'Direct reachability contains only S; the separately checked supplied U-to-B induction step still fails.', 'invariant_connectivity');
add('invariant_connects_bad_component', 'finite_invariant', {...invariant, transitions: [...invariant.transitions, {id: 's-u', from: 'S', to: 'U'}]},
  [eq('/result/status', 'COUNTEREXAMPLE_FOUND'), eq('/result/reachable_predicate_holds', false),
   eq('/result/counterexample/state_path', ['S', 'U', 'B']), eq('/result/counterexample/transition_ids', ['s-u', 'u-b'])],
  'One connecting edge makes B reachable through the exact two-edge concrete witness.', 'invariant_connectivity', 'VARIANT');

const abduction = {effects_semantics: 'ALL_LISTED_EFFECTS_MANDATORY', hypotheses: [
  {id: 'Halpha', effects: ['x', 'y']}, {id: 'Hbeta', effects: ['x']},
  {id: 'Hgamma', effects: ['y']}, {id: 'Hdelta', effects: ['z']}], observed_effects: ['x', 'y'], contradicted_effects: ['z']};
add('abduction_inclusion_minimal_dual', 'abductive_cover', abduction,
  [eq('/result/status', 'MINIMAL_EXPLANATIONS_FOUND'), eq('/result/minimal_explanations', [['Halpha'], ['Hbeta', 'Hgamma']]),
   eq('/result/minimum_cardinality', 1), eq('/result/minimality', 'SET_INCLUSION'),
   eq('/result/excluded_hypotheses', [{hypothesis_id: 'Hdelta', contradicted_effects: ['z']}])],
  'The singleton and two-element explanation are both inclusion-minimal. A separately implemented exhaustive subset oracle validates the duality with cuts.', 'abduction_conflict');
const conflict = clone(abduction); conflict.hypotheses[0].effects.push('z');
add('abduction_mandatory_conflict_excludes_shortcut', 'abductive_cover', conflict,
  [eq('/result/minimal_explanations', [['Hbeta', 'Hgamma']]), eq('/result/minimum_cardinality', 2),
   eq('/result/excluded_hypotheses', [{hypothesis_id: 'Halpha', contradicted_effects: ['z']}, {hypothesis_id: 'Hdelta', contradicted_effects: ['z']}])],
  'The shortcut now necessarily produces a contradicted effect, so only the longer explanation remains eligible.', 'abduction_conflict', 'VARIANT');

const cuts = {root: 'TOP', nodes: [
  {id: 'TOP', kind: 'AND', children: ['X', 'Y']},
  {id: 'X', kind: 'OR', children: ['Halpha', 'Hbeta']}, {id: 'Y', kind: 'OR', children: ['Halpha', 'Hgamma']},
  {id: 'Halpha', kind: 'LEAF'}, {id: 'Hbeta', kind: 'LEAF'}, {id: 'Hgamma', kind: 'LEAF'}]};
add('cuts_shared_identity_abduction_dual', 'minimal_cut_sets', cuts,
  [eq('/result/status', 'MINIMAL_CUT_SETS_COMPLETE'), eq('/result/minimal_cut_sets', [['Halpha'], ['Hbeta', 'Hgamma']]),
   eq('/result/assignments_examined', 8), eq('/result/independence_assumed', false)],
  '(Halpha OR Hbeta) AND (Halpha OR Hgamma) has exactly the abduction model minimal families, retaining one shared Halpha.', 'cuts_completeness');
add('cuts_candidates_found_but_budget_incomplete', 'minimal_cut_sets', {...cuts, max_assignments: 7},
  [eq('/result/status', 'UNKNOWN_RESOURCE_LIMIT'), eq('/result/enumeration_complete', false),
   eq('/result/minimal_cut_sets', [['Halpha'], ['Hbeta', 'Hgamma']]), eq('/result/assignments_examined', 7)],
  'Both actual minimal families have appeared before the final assignment, but the receipt must still disclose incomplete enumeration.', 'cuts_completeness', 'VARIANT');

add('nash_three_by_three_scope_control', 'nash', {
  row_payoffs: [[0, -1, 1], [1, 0, -1], [-1, 1, 0]], column_payoffs: [[0, 1, -1], [-1, 0, 1], [1, -1, 0]]},
  [eq('/result/pure_equilibria', []), eq('/result/strict_interior_mixed', null), eq('/result/mixed_status', 'NOT_COMPUTED_FOR_THIS_SIZE')],
  'Every pure rock-paper-scissors profile admits a profitable unilateral deviation. General 3x3 mixed equilibria are outside this implementation.', 'nash_general_scope');

add('harsanyi_skew_and_zero_mass', 'harsanyi', {states: [{id: 's0', probability: 0.25}, {id: 's1', probability: 0.75}, {id: 'zero', probability: 0}],
  actions: [{id: 'a', payoffs: [8, 0, 1000000000]}, {id: 'b', payoffs: [0, 4, -1000000000]}]},
  [eq('/result/values', [{id: 'a', expected_utility: 2}, {id: 'b', expected_utility: 3}]), eq('/result/maximizers', ['b']),
   eq('/result/beliefs_supplied', true), eq('/result/bayesian_equilibrium_computed', false)],
  'Quarter and three-quarter probabilities are exactly representable. The explicit zero-mass state contributes nothing.', 'harsanyi_zero_mass');

const tree = {root: 'ROOT', nodes: [
  {id: 'ROOT', player: 0, children: ['SAFE', 'OPPONENT']}, {id: 'SAFE', payoffs: [4, 0]},
  {id: 'OPPONENT', player: 1, children: ['FIRST', 'SECOND']}, {id: 'FIRST', payoffs: [8, 5]}, {id: 'SECOND', payoffs: [0, 5]}]};
add('selten_declared_tie_order_first', 'selten', tree,
  [eq('/result/root_payoffs', [8, 5]), eq('/result/choices/0/chosen', 'FIRST'), eq('/result/choices/1/chosen', 'OPPONENT'),
   eq('/result/tie_rule', 'FIRST_LISTED_CHILD')],
  'Player one is indifferent at five and chooses the first child; player zero then prefers eight to the safe four.', 'selten_tie_order');
const reversedTree = clone(tree); reversedTree.nodes[2].children.reverse();
add('selten_declared_tie_order_reversed', 'selten', reversedTree,
  [eq('/result/root_payoffs', [4, 0]), eq('/result/choices/0/chosen', 'SECOND'), eq('/result/choices/1/chosen', 'SAFE'),
   eq('/result/tie_rule', 'FIRST_LISTED_CHILD')],
  'Reversing an exact tie is intentionally observable: the continuation now gives player zero zero, so safe four is chosen.', 'selten_tie_order', 'VARIANT');

add('conservation_exact_tolerance_boundary', 'conservation', {unit: 'SYNTHETIC_UNITS', opening: 8, inflows: [3], outflows: [2], closing: 9.125, tolerance: 0.125},
  [eq('/result/expected_closing', 9), eq('/result/residual', 0.125), eq('/result/within_supplied_tolerance', true), eq('/result/causation_established', false)],
  'The independent balance is nine. The exactly representable residual one-eighth is included by the exactly equal declared tolerance.', 'conservation_tolerance');

const left = {native_id: 'object-1', version: 'v1', owner: 'owner', namespace: 'synthetic', label: 'old label', source_ref: 'synthetic:left'};
const right = {...left, version: 'v2', label: 'new label', source_ref: 'synthetic:right'};
add('identity_native_key_vs_version', 'identity', {left, right},
  [eq('/result/native_key_match', true), eq('/result/version_match', false), eq('/result/presentation_differs', true), eq('/result/identity_authenticated', false)],
  'The declared native tuple excludes version and label; their mismatches are explicitly separate results.', 'identity_native_id');
add('identity_different_native_id', 'identity', {left, right: {...right, native_id: 'object-2'}},
  [eq('/result/native_key_match', false), eq('/result/classification', 'DECLARED_NATIVE_KEY_DIFFERENCE'), eq('/result/identity_authenticated', false)],
  'Changing native ID changes the declared tuple even if the other fields remain as before.', 'identity_native_id', 'VARIANT');

const trace = {initial: 'A', transitions: [{from: 'A', event: 'tick', to: 'B'}, {from: 'B', event: 'tick', to: 'A'}],
  events: ['B', 'A', 'B'].map((observed_state, i) => ({event: 'tick', observed_state, source_ref: 'synthetic:tick:' + i}))};
add('trace_same_event_different_states', 'state_trace', trace,
  [eq('/result/trace_matches', true), eq('/result/reviewed_events', 3), eq('/result/final_state', 'B'), eq('/result/model_completeness_proven', false)],
  'Determinism is keyed by state and event together. Reusing tick in A and B is valid.', 'trace_first_divergence');
const badTrace = clone(trace); badTrace.events[1].observed_state = 'B';
add('trace_first_divergence_preserves_remainder', 'state_trace', badTrace,
  [eq('/result/trace_matches', false), eq('/result/first_divergence/index', 1), eq('/result/first_divergence/expected_state', 'A'),
   eq('/result/reviewed_events', 2), eq('/result/remaining_events', 1)],
  'The second event disagrees with B-to-A, so the third observation remains unevaluated.', 'trace_first_divergence', 'VARIANT');

const fault = {root: 'TOP', nodes: [{id: 'TOP', gate: 'AND', children: ['FALSE', 'UNKNOWN']}, {id: 'FALSE', value: false}, {id: 'UNKNOWN', value: null}]};
add('fault_false_dominates_unknown_and', 'fault_tree', fault,
  [eq('/result/root_value', false), eq('/result/nodes_evaluated', 3), eq('/result/probability_computed', false)],
  'False AND an unknown value is false for both possible completions of that leaf.', 'fault_three_valued');
const orFault = clone(fault); orFault.nodes[0].gate = 'OR';
add('fault_unknown_survives_or_false', 'fault_tree', orFault,
  [eq('/result/root_value', null), eq('/result/probability_computed', false)],
  'False OR an unknown value depends on the unobserved leaf and must remain unknown.', 'fault_three_valued', 'VARIANT');

add('fmea_equal_rpn_distinct_factor_profiles', 'fmea', {rows: [
  {id: 'high-severity', severity: 10, occurrence: 2, detection: 3, source_ref: 'synthetic:high'},
  {id: 'other-profile', severity: 3, occurrence: 4, detection: 5, source_ref: 'synthetic:other'},
  {id: 'minimum', severity: 1, occurrence: 1, detection: 1, source_ref: 'synthetic:minimum'}]},
  [eq('/result/rows/0/id', 'high-severity'), eq('/result/rows/0/rpn', 60), eq('/result/rows/1/id', 'other-profile'),
   eq('/result/rows/1/rpn', 60), eq('/result/rows/2/rpn', 1), eq('/result/rpn_is_probability', false)],
  '10*2*3 and 3*4*5 both equal sixty. The distinct factors and stable tie order remain visible.', 'fmea_tie');

const ach = {hypotheses: ['H0', 'H1'], evidence: [
  {id: 'e1', source_ref: 'synthetic:shared-source', assessments: ['SUPPORTS', 'CONTRADICTS']},
  {id: 'e2', source_ref: 'synthetic:shared-source', assessments: ['SUPPORTS', 'UNKNOWN']},
  {id: 'e3', source_ref: 'synthetic:other-source', assessments: ['UNKNOWN', 'NEUTRAL']}]};
add('ach_shared_source_rows_not_independent_truth', 'ach', ach,
  [eq('/result/hypotheses/0/counts', {SUPPORTS: 2, CONTRADICTS: 0, NEUTRAL: 0, UNKNOWN: 1}),
   eq('/result/hypotheses/1/counts', {SUPPORTS: 0, CONTRADICTS: 1, NEUTRAL: 1, UNKNOWN: 1}),
   eq('/result/truth_or_probability_computed', false)],
  'Distinct supplied evidence IDs count as two judgments even when their source reference is shared. The method computes no independence, probability or truth score.', 'ach_row_identity');
const duplicateAch = clone(ach); duplicateAch.evidence[1].id = 'e1';
reject('ach_duplicate_evidence_id_rejected', 'ach', duplicateAch, 'DUPLICATE_ID',
  'Repeated source references are permitted, but repeated evidence IDs are not distinct records.', 'ach_row_identity');

const coverage = {input_fingerprint: 'a'.repeat(64), pack_fingerprint: 'b'.repeat(64), checks: [
  {id: 'TEST_ONLY_A', state: 'SUPPORTED', source_refs: ['synthetic:a']}, {id: 'TEST_ONLY_B', state: 'SUPPORTED', source_refs: ['synthetic:b']}]};
add('coverage_supplied_subset_not_global_completion', 'coverage', coverage,
  [eq('/result/counts/SUPPORTED', 2), eq('/result/coverage_complete', false), eq('/result/persisted', false),
   eq('/result/source_references_resolved', false), eq('/result/receipt_scope', 'CALLER_REPORTED_SUBSET')],
  'Every supplied row being supported does not prove full pack coverage, resolved references or storage.', 'coverage_reference');
const missingCoverage = clone(coverage); missingCoverage.checks[1].source_refs = [];
reject('coverage_supported_without_reference', 'coverage', missingCoverage, 'SOURCE_REFERENCE_REQUIRED',
  'A supported caller record requires at least one declared source reference.', 'coverage_reference');

if (cases.length !== 44) throw Error('NONNUMERICAL_CASE_COUNT_MISMATCH:' + cases.length);
const numericalBytes = readFileSync(NUMERICAL_FILE);
const numericalCases = JSON.parse(numericalBytes);
if (!Array.isArray(numericalCases) || numericalCases.length !== 4) throw Error('FOUR_OWNER_NUMERICAL_CASES_REQUIRED');
const exactOracleBytes = readFileSync(EXACT_ORACLE_FILE);
const exactOracle = JSON.parse(exactOracleBytes);
for (const item of numericalCases) {
  const numerical = clone(item);
  const assertions = [], oracleAssertions = [], referenceAssertions = [];
  let oracleMatchExpected;
  if (numerical.method === 'nash') {
    assertions.push(eq('/result/mixed_status', 'STRICT_INTERIOR_SOLUTION'));
    oracleAssertions.push(eq('/result/strict_interior_mixed/row_probabilities/0', 0.5),
      eq('/result/strict_interior_mixed/column_probabilities/0', exactOracle.nash.exact_column_probability.nearest_binary64));
    referenceAssertions.push(eq('/result/strict_interior_mixed/column_probabilities/0', numerical.expectation.native_observed_column_probability));
    oracleMatchExpected = numerical.case_id === 'numerical_nash_column_shift_control';
  } else if (numerical.method === 'harsanyi') {
    oracleAssertions.push(eq('/result/maximizers', numerical.expectation.exact_maximizers));
    referenceAssertions.push(eq('/result/maximizers', numerical.expectation.native_observed_maximizers));
    oracleMatchExpected = false;
  } else if (numerical.method === 'conservation') {
    oracleAssertions.push(eq('/result/expected_closing', exactOracle.conservation.exact_expected_closing.nearest_binary64),
      eq('/result/residual', exactOracle.conservation.exact_residual.nearest_binary64),
      eq('/result/within_supplied_tolerance', false));
    referenceAssertions.push(eq('/result/expected_closing', 0), eq('/result/residual', 0), eq('/result/within_supplied_tolerance', true));
    oracleMatchExpected = false;
  } else throw Error('UNEXPECTED_NUMERICAL_METHOD');
  numerical.expectation = {...numerical.expectation, outcome: 'RESULT', assertions,
    exact_oracle_assertions: oracleAssertions, expected_exact_oracle_match: oracleMatchExpected,
    prior_observed_reference_assertions: referenceAssertions,
    comparison_rule: 'Exact oracle disagreement is retained as a counterexample, not counted as semantic correctness.'};
  numerical.comparison = {pair_id: numerical.method === 'conservation' ? 'numerical_conservation' : 'numerical_nash_harsanyi', role: 'NUMERICAL_PROBE'};
  numerical.synthetic_inputs_only = true;
  numerical.owner_evidence = {path: NUMERICAL_FILE, sha256: sha(numericalBytes), oracle_path: EXACT_ORACLE_FILE, oracle_sha256: sha(exactOracleBytes)};
  cases.push(numerical);
}
const catalog = getMethodCatalog();
if (cases.length !== 48 || new Set(cases.map(c => c.case_id)).size !== 48) throw Error('CASE_COUNT_OR_DUPLICATE_ID');
if (new Set(cases.map(c => c.method)).size !== 24) throw Error('NATIVE_METHOD_COVERAGE_MISMATCH');
for (const item of cases) {
  if (canonical(clone(item)) !== canonical(item)) throw Error('JSON_UNSAFE_CASE:' + item.case_id);
  item.input_schema_sha256 = await digest(getMethodCatalog({method: item.method}).input_schemas[item.method]);
  item.expected_model_fingerprint = await digest({method: item.method, input: item.input});
}
const corpus = {version: 'MPC_NATIVE_LOCAL_LIVE_DIFFERENTIAL_V16_1', case_count: cases.length,
  source_identity: sourceIdentity, native_catalog_version: catalog.version,
  input_schema_rule: 'Read the selected current native catalog schema before calling evaluate_method. These hashes bind the inspected local schemas.',
  same_input_comparison: 'Compare full structured results, model fingerprint and expected errors for identical JSON inputs. Semantic transformations have separately stated expected relations.',
  cases};

function frozen(value) {
  if (value && typeof value === 'object') { Object.values(value).forEach(frozen); Object.freeze(value); }
  return value;
}
function atPath(value, path) {
  for (const part of path.split('/').slice(1)) {
    const key = part.replaceAll('~1', '/').replaceAll('~0', '~');
    if (value === null || typeof value !== 'object' || !Object.hasOwn(value, key)) return {found: false};
    value = value[key];
  }
  return {found: true, value};
}
function checks(receipt, assertions) {
  return assertions.map(assertion => {
    const actual = atPath(receipt, assertion.path);
    return {...assertion, actual: actual.found ? actual.value : {missing_path: true},
      pass: actual.found && canonical(actual.value) === canonical(assertion.value)};
  });
}
const results = [], startedAt = new Date().toISOString();
let entryCalls = 0;
for (const item of cases) {
  const supplied = frozen(clone(item.input));
  const beforeInput = canonical(supplied);
  let schemaAdmission = {admitted: true}, receipt = null, error = null;
  try { validate(supplied, getMethodCatalog({method: item.method}).input_schemas[item.method]); }
  catch (e) { schemaAdmission = {admitted: false, error: e.message}; }
  const started = performance.now();
  try { entryCalls++; receipt = await evaluateMethod({method: item.method, input: supplied}); }
  catch (e) { error = {name: e.name, message: e.message}; }
  const envelopeChecks = receipt ? checks(receipt, [eq('/status', 'BOUNDED_MODEL_RESULT'), eq('/method', item.method),
    eq('/implementation_version', catalog.version), eq('/model_fingerprint', item.expected_model_fingerprint),
    eq('/source_authentication', false), eq('/canonical_promotion', false), eq('/court_release_allowed', false), eq('/external_action_authorized', false)]) : [];
  const semanticChecks = receipt ? checks(receipt, item.expectation.assertions ?? []) : [];
  const oracleChecks = receipt ? checks(receipt, item.expectation.exact_oracle_assertions ?? []) : [];
  const referenceChecks = receipt ? checks(receipt, item.expectation.prior_observed_reference_assertions ?? []) : [];
  const exactOracleMatch = oracleChecks.length ? oracleChecks.every(c => c.pass) : null;
  const expectedOutcome = item.expectation.outcome === 'ERROR' ? error?.message === item.expectation.error_message : receipt !== null;
  const inputUnchanged = beforeInput === canonical(supplied);
  const validationPass = expectedOutcome && inputUnchanged && envelopeChecks.every(c => c.pass) && semanticChecks.every(c => c.pass) &&
    referenceChecks.every(c => c.pass) && (exactOracleMatch === null || exactOracleMatch === item.expectation.expected_exact_oracle_match);
  results.push({case_id: item.case_id, method: item.method, request: {method: item.method, input: item.input},
    schema_admission: schemaAdmission, raw_native_receipt: receipt, raw_native_error: error,
    elapsed_ms: performance.now() - started, input_unchanged: inputUnchanged,
    envelope_checks: envelopeChecks, semantic_checks: semanticChecks, exact_oracle_checks: oracleChecks,
    prior_reference_checks: referenceChecks, exact_oracle_match: exactOracleMatch,
    semantic_assessment: exactOracleMatch === false ? 'COUNTEREXAMPLE_TO_EXACT_SUPPLIED_NUMBER_ORACLE' : error ? 'EXPECTED_REJECTION' : 'STATED_ASSERTIONS_MATCH',
    harness_expectation_met: validationPass});
}

// Independent small oracle: enumerate all subsets recursively, then remove
// every proper superset of another successful set. Native code uses numeric
// masks and prefix pruning; this implementation does neither.
function allSubsets(ids) {
  if (!ids.length) return [[]];
  const tail = allSubsets(ids.slice(1));
  return [...tail, ...tail.map(xs => [ids[0], ...xs])];
}
function normalizedFamilies(families) {
  return families.map(xs => [...xs].sort()).sort((a, b) => a.length - b.length || canonical(a).localeCompare(canonical(b)));
}
function inclusionMinimal(successful) {
  return normalizedFamilies(successful.filter(candidate => !successful.some(other => other.length < candidate.length && other.every(x => candidate.includes(x)))));
}
function abductionOracle(input) {
  const eligible = input.hypotheses.filter(h => !h.effects.some(e => input.contradicted_effects.includes(e)));
  const subsets = allSubsets(eligible.map(h => h.id));
  const successful = subsets.filter(ids => {
    const effects = new Set(eligible.filter(h => ids.includes(h.id)).flatMap(h => h.effects));
    return input.observed_effects.every(e => effects.has(e));
  });
  return {eligible: eligible.map(h => h.id), enumerated_subsets: subsets.length, successful_subsets: successful,
    minimal_explanations: inclusionMinimal(successful)};
}
const baseOracle = abductionOracle(abduction), conflictOracle = abductionOracle(conflict);
const cutSubsets = allSubsets(['Halpha', 'Hbeta', 'Hgamma']);
const cutSuccesses = cutSubsets.filter(xs => (xs.includes('Halpha') || xs.includes('Hbeta')) && (xs.includes('Halpha') || xs.includes('Hgamma')));
const cutOracle = inclusionMinimal(cutSuccesses);
const byCase = new Map(results.map(r => [r.case_id, r]));
const familyEqual = (a, b) => canonical(normalizedFamilies(a)) === canonical(normalizedFamilies(b));
const independentOracle = {
  version: 'FINITE_ABDUCTION_CUT_DUAL_ORACLE_1', assumptions: ['All declared effects are mandatory.', 'Only supplied hypotheses are considered.', 'Shared Halpha is one hypothesis and one Boolean leaf.'],
  base_abduction: baseOracle, conflict_abduction: conflictOracle,
  cut_oracle: {enumerated_subsets: cutSubsets.length, successful_subsets: cutSuccesses, minimal_cut_sets: cutOracle},
  base_abduction_match: familyEqual(baseOracle.minimal_explanations, byCase.get('abduction_inclusion_minimal_dual').raw_native_receipt.result.minimal_explanations),
  conflict_abduction_match: familyEqual(conflictOracle.minimal_explanations, byCase.get('abduction_mandatory_conflict_excludes_shortcut').raw_native_receipt.result.minimal_explanations),
  cut_match: familyEqual(cutOracle, byCase.get('cuts_shared_identity_abduction_dual').raw_native_receipt.result.minimal_cut_sets),
  independent_dual_match: familyEqual(baseOracle.minimal_explanations, cutOracle),
  external_facts_authenticated: false
};
const after = sourceFiles();
const sourceUnchanged = canonical(before) === canonical(after);
const oraclePassed = independentOracle.base_abduction_match && independentOracle.conflict_abduction_match && independentOracle.cut_match && independentOracle.independent_dual_match;
const summary = {version: 'MPC_NATIVE_DIFFERENTIAL_LOCAL_VALIDATION_V16_1', started_at_utc: startedAt, completed_at_utc: new Date().toISOString(),
  node: process.version, execution_host: 'CHATGPT_LINUX', native_evaluator_entry_calls: entryCalls,
  cases_executed: results.length, distinct_native_methods: new Set(results.map(r => r.method)).size,
  native_successful_returns: results.filter(r => r.raw_native_receipt !== null).length,
  expected_native_rejections: results.filter(r => r.raw_native_error && r.harness_expectation_met).length,
  all_inputs_json_round_trippable: true, all_inputs_native_schema_admitted: results.every(r => r.schema_admission.admitted),
  unexpected_harness_failures: results.filter(r => !r.harness_expectation_met).map(r => r.case_id),
  numerical_exact_oracle_counterexample_cases: results.filter(r => r.exact_oracle_match === false).map(r => r.case_id),
  numerical_exact_oracle_agreement_cases: results.filter(r => r.exact_oracle_match === true).map(r => r.case_id),
  numerical_cases_are_not_distinct_defect_counts: true,
  independent_abduction_cut_oracle_passed: oraclePassed, source_files_unchanged: sourceUnchanged,
  source_working_tree_dirty_after: Boolean(git(['status', '--porcelain=v1'])), source_identity: sourceIdentity,
  hosted_calls_performed: false, source_edits: false, controller_or_package_advanced: false,
  interpretation: 'A known exact-oracle counterexample remains a counterexample even when its expected exposure is reproduced by this harness.'};
if (!existsSync(OUTPUT)) mkdirSync(OUTPUT, {recursive: true});
const artifacts = {
  'native-differential-cases.json': corpus,
  'native-differential-local-receipts.json': {version: 'MPC_NATIVE_DIFFERENTIAL_RECEIPTS_V16_1', source_identity: sourceIdentity, receipts: results},
  'native-differential-independent-oracle.json': independentOracle,
  'native-differential-local-summary.json': summary
};
for (const path of [...Object.keys(artifacts), 'native-differential-artifact-manifest.json']) {
  if (existsSync(resolve(OUTPUT, path))) throw Error('NEW_OUTPUT_FILES_REQUIRED:' + path);
}
const manifestFiles = [];
for (const [path, value] of Object.entries(artifacts)) {
  const bytes = Buffer.from(JSON.stringify(value, null, 2) + '\n');
  writeFileSync(resolve(OUTPUT, path), bytes, {flag: 'wx'});
  const stored = readFileSync(resolve(OUTPUT, path));
  if (sha(stored) !== sha(bytes)) throw Error('ARTIFACT_READBACK_MISMATCH:' + path);
  manifestFiles.push({path, bytes: stored.length, sha256: sha(stored)});
}
const generatorBytes = readFileSync(fileURLToPath(import.meta.url));
const manifest = {version: 'MPC_NATIVE_DIFFERENTIAL_ARTIFACT_MANIFEST_1', algorithm: 'SHA-256',
  generator: {path: fileURLToPath(import.meta.url), sha256: sha(generatorBytes)},
  owner_numerical_cases: {path: NUMERICAL_FILE, sha256: sha(numericalBytes)},
  owner_exact_oracle: {path: EXACT_ORACLE_FILE, sha256: sha(exactOracleBytes)}, files: manifestFiles};
writeFileSync(resolve(OUTPUT, 'native-differential-artifact-manifest.json'), JSON.stringify(manifest, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({...summary, artifacts: manifestFiles}, null, 2));
if (summary.unexpected_harness_failures.length || !oraclePassed || !sourceUnchanged) process.exitCode = 1;
