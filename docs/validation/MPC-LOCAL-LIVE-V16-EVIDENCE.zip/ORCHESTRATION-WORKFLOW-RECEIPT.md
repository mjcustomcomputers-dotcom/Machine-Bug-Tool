# MPC local/live orchestration and evidence workflow

## Changes ready for integration

The router now starts with the work to do. Its leading fields are `work_stage`, `fact_summary`, `next_action`, and `workflow`. A next action names the source ID, owner, native locator, version, target fact, and completion condition whenever those coordinates are available.

| Available task inputs | Work stage | Next action |
| --- | --- | --- |
| A source pointer, missing content, or content from an older version | Evidence acquisition | Read the exact current record, or locate the missing native record |
| Source content at the declared version | Analysis | Interpret the record and formulate the selected model |
| A specific claim, source references, expected support, expected contrary evidence, and the required content | Verification | Check that claim against those records |
| A verification request missing its specific target | Analysis | Supply the missing claim or outcome conditions |
| Legacy explicit atomic execution with no workflow request | Analysis of supplied models | Execute the caller's bounded model request and interpret the results |

An explicit acquisition request, an AUTO request with required source gaps, or a verification request missing source content changes the effective atomic mode to `PLAN`. The original `EXECUTE_SUPPLIED_MODELS` request and the prepared model IDs remain available. Supplying the current source content and moving to analysis restores the requested execution. The router itself performs no connector retrieval; it works with supplied records and names the next acquisition target.

The optional input is:

```json
{
  "workflow": {
    "requested_phase": "AUTO",
    "records": [
      {
        "source_ref": "BRIDGE",
        "version": "exact-declared-source-version",
        "content": "Actual supplied record text"
      }
    ],
    "verification_target": {
      "claim": "One specific proposition",
      "source_refs": ["BRIDGE"],
      "expected_support": "What record content would support the proposition",
      "expected_counterevidence": "What record content would defeat it"
    }
  }
}
```

`verification_target` is optional. Its presence does not authenticate a claim. Source records must resolve to a declared source ID and match its version. Empty content and stale versions remain acquisition work. Content fingerprints change when the supplied content changes. The current target's sources take priority over unrelated watch questions.

## Two confirmed orchestration repairs

The prior router selected the first four method candidates in question insertion order. In the saved five-question case, four WATCH candidates without models displaced the only REQUIRED candidate with a supplied model. Moving the same required question to the front changed selection.

The repaired selection uses the strongest attached question state, schema readiness within that state, and a stable method ID tie break. Missing required obligations still precede optional ready work. The selection cap and remaining-candidate count remain explicit. All 120 permutations of the five-question fixture retain the same selected-method and full-candidate semantics. The revision is `UMTB4-PRIORITY-1`.

The compatibility sweep previously returned `method_execution_performed: true` and two nested executed model receipts while adding `method_execution.status: NOT_EXECUTED_BY_SWEEP`. Its summary now follows the actual atomic receipt, including attempted and successful evaluations, incomplete execution, and both continuation frontiers. Deferred acquisition work reports `MODELS_READY_AFTER_EVIDENCE_ACQUISITION`. The summary revision is `UMTB4-WORKFLOW-EXECUTION-SUMMARY-2`.

Root separately confirmed both original behaviors through the live connector. The three preserved comparisons are `O5_REQUIRED_LAST`, `O5_REQUIRED_FIRST`, and `O1_UMTB4_EXEC`, with input, local-before, and live receipts beside this document.

## Evidence and verification

The initial read-only reproduction ran 24 exact local call packets against hydrated local commit `6273be1cf94736aed73b143bf25d76d3c55ab561`. All 31 expected observations occurred, including the defects being investigated. This is a reproduction result, not a clean-product score. Four calls intentionally produced contract errors.

Direct `identity` receipts match the atomic baseline and changed-owner model receipts. Route `models` only establishes schema readiness; it does not compute a result. A syntactically valid nondeterministic transition model is therefore accepted as schema-ready by routing and rejected by `evaluate_method`. PLAN, removed bindings, masked nonnullable inputs, mismatched objects, stale source versions, and unfinished execution retain their distinct outcomes.

Final focused verification ran:

```sh
node --test --test-reporter=spec tests/evidence-workflow.test.mjs tests/router.test.mjs tests/review-bridge-execution.test.mjs tests/atomic-review.test.mjs
```

Result: **46 passed, zero failed**. This includes 14 phase tests, the selection permutation exercise, and the retained atomic execution controls. Exact command output is saved in `workflow-focused-test.json`; the six implementation/test file hashes are in `workflow-source-manifest.json`. Full-suite, build, native acquisition demonstration, plugin changes, and portable-distribution verification belong to the parent integration task and its separate receipts.

## Retained boundaries and one follow-up

The 24 native evaluator IDs, registered classifier IDs, old controller records, evaluator input contracts, and default atomic PLAN behavior remain intact. Source content availability is separate from source authentication. The workflow's leading fields express the current work; the legacy `status` field still describes classifier routing. Optional `rendered_output` remains the caller's requested presentation rather than an automatically generated workflow narrative.

The atomic baseline continuation token binds atoms, sources, models, and checks, but not the transform enumeration. The saved `O4_CHANGED_PLAN_RESUME` case reverses a cross-product choice order between pages while preserving the baseline token. Stitching those pages repeats the alpha cases and omits the original beta counterexamples. This remains a recorded follow-up: a future plan-specific continuation identity should bind the enumeration without reinterpreting the existing baseline token. The router/bridge repairs did not change that native atomic contract.
