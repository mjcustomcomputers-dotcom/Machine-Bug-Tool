import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {callTool} from '../Machine-Bug-Tool-Local-Live/lib/tools.mjs';
import {canonical, digest} from '../Machine-Bug-Tool-Local-Live/lib/universal.mjs';

// Synthetic local function calls only. This script does not start a server,
// manufacture authentication, contact the hosted connector, or edit source.
const root = fileURLToPath(new URL('../Machine-Bug-Tool-Local-Live/', import.meta.url));
const output = new URL('./', import.meta.url);
const fixture = JSON.parse(await readFile(new URL('../Machine-Bug-Tool-Local-Live/tests/fixtures/atomic-owner-variation.json', import.meta.url), 'utf8'));
const clone = value => structuredClone(value);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const sourcePaths = [
  'lib/tools.mjs', 'lib/methods.mjs', 'lib/schema.mjs', 'lib/universal.mjs',
  'lib/universal-router.mjs', 'lib/review-bridge.mjs', 'lib/atomic-review.mjs',
  'lib/solid-state.mjs', 'lib/typed-references.mjs',
  'lib/atomic-models.mjs', 'lib/forensic-models.mjs', 'lib/deferred-models.mjs',
  'tests/fixtures/atomic-owner-variation.json', 'tests/atomic-review.test.mjs',
  'tests/router.test.mjs'
];
async function sourceHashes() {
  return Promise.all(sourcePaths.map(async path => {
    const bytes = await readFile(new URL(path, new URL('../Machine-Bug-Tool-Local-Live/', import.meta.url)));
    return {path, bytes: bytes.length, sha256: sha(bytes)};
  }));
}
const before = await sourceHashes();
const originalCore = {
  'lib/universal-router.mjs': '639575fc50fcce37b039b3c6dbc4cbdeadc238a20123878e6a014785156b02b3',
  'lib/review-bridge.mjs': 'd768411687a4690fe1182e2a888f9dd53dd4e3fdd62b8db979bddab7b78a5714'
};
if (before.some(file => originalCore[file.path] && originalCore[file.path] !== file.sha256)) {
  throw new Error('Baseline source changed. Preserve the before receipts; use capture-orchestration-after.mjs for the repaired worktree.');
}
const head = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
const statusBefore = execFileSync('git', ['status', '--short'], {cwd: root, encoding: 'utf8'});
const started = new Date().toISOString();

function baseRoute() {
  return {
    problem: 'Synthetic native owner equality across the same declared record.',
    object_id: fixture.object_id,
    unit_of_analysis: 'One declared record owner coordinate',
    domain_profile: 'GENERAL',
    sources: fixture.sources.map(source => ({
      id: source.id, owner: source.owner, type: 'SYNTHETIC_FIXTURE',
      version: source.version, time: 'Synthetic fixture time; not a real event',
      native_locator: source.native_locator
    })),
    structures: [{id: 'SOURCE', type: 'SOURCE_RECORD', subject_ids: [fixture.object_id], source_refs: ['FIXTURE']}],
    questions: [{
      id: 'OWNER-QUESTION', kind: 'SOURCE_AUTHORITY',
      invariant: 'Supplied native namespace, native ID and owner coordinates match.',
      structure_ids: ['SOURCE'], rule_source_refs: ['RULE'], necessity: 'REQUIRED',
      applicability: 'APPLIES', lenses: []
    }],
    models: [{method: 'identity', input: clone(fixture.models[0].input)}],
    stop_condition: 'Synthetic model review only; no source authentication or target conclusion.'
  };
}
function legacy(route) {
  return {
    namespace: 'SYNTHETIC', object_id: route.object_id, actor: 'fixture-author',
    action: 'synthetic controlled comparison', state_before: 'supplied baseline',
    state_after: 'supplied variant', channel: 'offline',
    invariant: 'Retain exact supplied-model semantics across compatibility surfaces.',
    context: 'UMTB4:' + JSON.stringify(route)
  };
}
function transform(operator, atomIds = [], extra = {}) {
  return {
    id: 'CONTROL', operator, atom_ids: atomIds,
    rationale: 'Finite synthetic orchestration control.',
    material_change_basis: 'The declared coordinate may alter the explicitly supplied model.',
    source_refs: ['FIXTURE'], ...extra
  };
}
const baseFingerprint = atomic => digest({
  project_id: atomic.project_id, object_id: atomic.object_id, namespace: atomic.namespace,
  atoms: atomic.atoms, sources: atomic.sources, models: atomic.models ?? [], checks: atomic.checks ?? []
});
const cases = [];
function add(id, family, tool, args, purpose, priority = 'P1') {
  cases.push({id, family, replay_priority: priority, tool, arguments: clone(args),
    argument_json_bytes: Buffer.byteLength(JSON.stringify(args)), purpose});
}

// 1. Identical mathematical inputs should retain the entire evaluator receipt.
const baseModel = {method: 'identity', input: clone(fixture.models[0].input)};
const differentModel = clone(baseModel);
differentModel.input.left.owner = 'beta';
const readyRoute = baseRoute();
const executableRoute = {...clone(readyRoute), atomic_review: clone(fixture)};
add('O1_DIRECT_BASE', 'receipt-parity', 'evaluate_method', baseModel, 'Native key match; exact baseline evaluator receipt.', 'P0');
add('O1_DIRECT_OWNER_DIFF', 'receipt-parity', 'evaluate_method', differentModel, 'Owner differs; exact expected atomic SWAP model receipt.', 'P0');
add('O1_ROUTE_READY', 'receipt-parity', 'route_problem', readyRoute, 'Schema readiness only: no model execution or computed identity result.', 'P0');
add('O1_ATOMIC_EXEC', 'receipt-parity', 'review_atomic_variants', fixture, 'Baseline equals direct baseline; SWAP equals direct changed owner.', 'P0');
add('O1_ROUTE_EXEC', 'receipt-parity', 'route_problem', executableRoute, 'Nested atomic receipt equals dedicated atomic result byte-for-byte after canonical serialization.', 'P0');
add('O1_UMTB4_EXEC', 'receipt-parity', 'business_logic_sweep', legacy(executableRoute), 'Compatibility wrapper must preserve nested receipts and routing fingerprint.', 'P0');
add('O1_LEGACY_ALIAS_EXEC', 'receipt-parity', 'analyze_business_logic', legacy(executableRoute), 'Legacy alias has the same routing/atomic semantics; the business sweep adds bridge metadata.', 'P2');

// 2. Negative controls must differ even though they share a model or wrapper.
const plan = clone(fixture); delete plan.mode;
const mask = clone(fixture); mask.transforms = [transform('MASK / HIDE CHANNEL', ['OWNER-A'])];
const remove = clone(fixture); remove.transforms = [transform('REMOVE / ABLATE', ['OWNER-A'])];
const noFrame = {
  problem: readyRoute.problem, object_id: readyRoute.object_id,
  unit_of_analysis: readyRoute.unit_of_analysis, domain_profile: 'GENERAL',
  atomic_review: clone(fixture)
};
const wrongAtomic = clone(executableRoute); wrongAtomic.atomic_review.object_id = 'another-object';
const wrongLegacy = legacy(executableRoute); wrongLegacy.object_id = 'another-object';
add('O2_DEFAULT_PLAN', 'deliberate-non-equivalence', 'review_atomic_variants', plan, 'Omitting execution mode leaves model-output checks UNKNOWN.', 'P0');
add('O2_MASK_BINDING', 'deliberate-non-equivalence', 'review_atomic_variants', mask, 'Null cannot fill the required owner string: variant model blocked; no false counterexample.', 'P1');
add('O2_REMOVE_BINDING', 'deliberate-non-equivalence', 'review_atomic_variants', remove, 'Removed atom blocks the variant projection; no baseline receipt reuse.', 'P1');
add('O2_NO_FRAME_EXEC', 'deliberate-non-equivalence', 'route_problem', noFrame, 'Outer typed routing remains BLOCKED while the separately explicit nested atomic model executes.', 'P1');
add('O2_WRONG_ATOMIC_OBJECT', 'deliberate-non-equivalence', 'route_problem', wrongAtomic, 'Different route/atomic object IDs must reject.', 'P1');
add('O2_WRONG_ROUTE_OBJECT', 'deliberate-non-equivalence', 'business_logic_sweep', wrongLegacy, 'Different legacy/routing object IDs must reject.', 'P1');
const nonDeterministicModel = {
  method: 'state_trace',
  input: {initial: 'S', transitions: [{from: 'S', event: 'advance', to: 'A'}, {from: 'S', event: 'advance', to: 'B'}], events: []}
};
const nonDeterministicRoute = baseRoute();
nonDeterministicRoute.structures = [{id: 'TRACE', type: 'STATE_TRACE', subject_ids: [fixture.object_id], source_refs: ['FIXTURE']}];
nonDeterministicRoute.questions = [{...nonDeterministicRoute.questions[0], id: 'TRACE-QUESTION', kind: 'TRANSITION', structure_ids: ['TRACE']}];
nonDeterministicRoute.models = [clone(nonDeterministicModel)];
add('O2_NONDETERMINISTIC_DIRECT', 'deliberate-non-equivalence', 'evaluate_method', nonDeterministicModel, 'Well-shaped transition table fails the evaluator semantic precondition.', 'P1');
add('O2_NONDETERMINISTIC_ROUTE', 'deliberate-non-equivalence', 'route_problem', nonDeterministicRoute, 'SCHEMA_VALID_CALLER_MODEL is expected despite an evaluator rejection; readiness is not semantic validation.', 'P1');

// 3. There are two continuation frontiers: materialization and execution.
const budget = clone(fixture);
budget.models.push({...clone(budget.models[0]), id: 'SECOND-MODEL'});
budget.transforms = Array.from({length: 16}, (_, i) => transform('INVARIANT TEST', [], {id: 'V' + i}));
budget.max_variants = 16;
const resume = {...clone(budget), variant_offset: 15, max_variants: 1, expected_base_fingerprint: await baseFingerprint(budget)};
const stale = clone(resume); stale.sources[0].version = '2';
add('O3_BUDGET', 'execution-continuation', 'review_atomic_variants', budget, '32 evaluations are spent before the last variant; pagination null does not imply completion.', 'P1');
add('O3_RESUME', 'execution-continuation', 'review_atomic_variants', resume, 'Resume the pending index against the same source-bound baseline; preserve variant fingerprint.', 'P1');
add('O3_STALE_SOURCE_RESUME', 'execution-continuation', 'review_atomic_variants', stale, 'Changing a declared source version must reject an old baseline continuation.', 'P1');

// 4. A baseline token currently does not bind the transform enumeration plan.
const page = clone(fixture);
page.transforms = [transform('CROSS PRODUCT', [], {
  id: 'OWNER-GRID', choices: [{atom_id: 'OWNER-A', values: ['alpha', 'beta']}, {atom_id: 'OWNER-B', values: ['beta', 'gamma']}]
})];
page.max_variants = 2;
const page2 = {...clone(page), variant_offset: 2, expected_base_fingerprint: await baseFingerprint(page)};
const full = {...clone(page), max_variants: 4};
const changedPlan = clone(page2); changedPlan.transforms[0].choices[0].values.reverse();
add('O4_PAGE_ONE', 'plan-bound-pagination', 'review_atomic_variants', page, 'Materialize first two grid entries only; execution_complete is local to this returned page.', 'P1');
add('O4_PAGE_TWO', 'plan-bound-pagination', 'review_atomic_variants', page2, 'Unchanged plan reproduces the latter half of the one-page grid.', 'P1');
add('O4_FULL_GRID', 'plan-bound-pagination', 'review_atomic_variants', full, 'Reference enumeration: owner alpha, alpha, beta, beta.', 'P1');
add('O4_CHANGED_PLAN_RESUME', 'plan-bound-pagination', 'review_atomic_variants', changedPlan, 'Same baseline token accepts reordered choices; stitching with page one repeats alpha and skips the original beta counterexamples.', 'P0');

// 5. Current selection follows insertion order, independent of readiness/priority.
const priorityRoute = baseRoute();
const priorityRows = [
  ['CONFIG-WATCH', 'CONFIGURATION', 'CONFIGURATION'],
  ['ALTERNATIVES-WATCH', 'ALTERNATIVES', 'HYPOTHESES'],
  ['PRECONDITION-WATCH', 'CONTROL_PRECONDITION', 'CONTROL_ACTION'],
  ['ORDER-WATCH', 'ORDER', 'EVENT_TRACE'],
  ['OWNER-REQUIRED', 'SOURCE_AUTHORITY', 'SOURCE_RECORD']
];
priorityRoute.structures = priorityRows.map(([id, , type]) => ({id: id + '-STRUCTURE', type, subject_ids: [fixture.object_id], source_refs: ['FIXTURE']}));
priorityRoute.questions = priorityRows.map(([id, kind], i) => ({
  id, kind, invariant: 'Synthetic per-question invariant ' + id,
  structure_ids: [id + '-STRUCTURE'], rule_source_refs: ['RULE'],
  necessity: i === 4 ? 'REQUIRED' : 'OPTIONAL', applicability: i === 4 ? 'APPLIES' : 'UNKNOWN', lenses: []
}));
const reordered = clone(priorityRoute); reordered.questions.unshift(reordered.questions.pop());
add('O5_REQUIRED_LAST', 'priority-selection', 'route_problem', priorityRoute, 'Four WATCH candidates occupy the selected prefix; the only REQUIRED and model-ready candidate remains fifth.', 'P0');
add('O5_REQUIRED_FIRST', 'priority-selection', 'route_problem', reordered, 'Permuting the same question set includes the required model-ready candidate.', 'P0');

const familyContracts = [
  {id: 'receipt-parity', criterion: 'For identical method/input, compare the full nested evaluator receipt. Compare atomic result separately from route/legacy wrapper fields; routing_fingerprint equals the direct route input_fingerprint.'},
  {id: 'deliberate-non-equivalence', criterion: 'PLAN, schema readiness, blocked projections, evaluator semantic rejection, and object mismatch are distinct states. Never require each surface to claim execution merely because a model was supplied.'},
  {id: 'execution-continuation', criterion: 'A completed traversal requires both frontiers exhausted and relevant execution complete. Resumption repeats baseline execution and may change aggregate call counts.'},
  {id: 'plan-bound-pagination', criterion: 'With an identical plan, concatenate stable variant indices/fingerprints/results. A changed enumeration plan needs a separate plan token before the prior page cursor can mean the same work.'},
  {id: 'priority-selection', criterion: 'Question-set semantics are unchanged by permutation, but the current bounded selected-method prefix is order-sensitive. This is an orchestration improvement target, not a promise of global minimum selection.'}
];
const packet = {
  schema_version: 'LOCAL_LIVE_ORCHESTRATION_PROPOSALS_V16.1', source_head: head,
  synthetic_fixture: 'tests/fixtures/atomic-owner-variation.json',
  execution_scope: 'LOCAL_FUNCTION_CALLS_ONLY', hosted_executed_by_this_script: false,
  families: familyContracts, cases
};
await writeFile(new URL('orchestration-cases.json', output), JSON.stringify(packet, null, 2) + '\n');

const receipts = [];
for (const testcase of cases) {
  try {
    const result = await callTool(testcase.tool, clone(testcase.arguments));
    receipts.push({id: testcase.id, tool: testcase.tool, returned: true, result});
  } catch (error) {
    receipts.push({id: testcase.id, tool: testcase.tool, returned: false, error: {name: error.name, message: error.message}});
  }
}
const byId = new Map(receipts.map(row => [row.id, row]));
const r = id => byId.get(id).result;
const error = id => byId.get(id).error?.message;
const same = (a, b) => canonical(a) === canonical(b);
const checks = [];
function check(id, condition, details = null) { checks.push({id, expectation_met: !!condition, details}); }
check('direct owner change changes native key result', r('O1_DIRECT_BASE')?.result.native_key_match === true && r('O1_DIRECT_OWNER_DIFF')?.result.native_key_match === false);
check('atomic baseline receipt equals direct receipt', same(r('O1_ATOMIC_EXEC')?.baseline.model_results[0].receipt, r('O1_DIRECT_BASE')));
check('atomic owner-swap receipt equals explicit changed model receipt', same(r('O1_ATOMIC_EXEC')?.variants[0].model_results[0].receipt, r('O1_DIRECT_OWNER_DIFF')));
for (const id of ['O1_ROUTE_EXEC', 'O1_UMTB4_EXEC', 'O1_LEGACY_ALIAS_EXEC']) {
  check(id + ' nested atomic receipt equals dedicated result', same(r(id)?.atomic_review, r('O1_ATOMIC_EXEC')));
  check(id + ' reports actual nested execution', r(id)?.method_execution_performed === true);
}
check('route models are readiness only', r('O1_ROUTE_READY')?.method_execution_performed === false && r('O1_ROUTE_READY')?.selected_methods[0].input_readiness === 'SCHEMA_VALID_CALLER_MODEL' && r('O1_ROUTE_READY')?.atomic_review === null);
check('UMTB4 preserves the direct route fingerprint', r('O1_UMTB4_EXEC')?.routing_fingerprint === r('O1_ROUTE_EXEC')?.input_fingerprint);
check('different wrapper envelope has a different input fingerprint', r('O1_UMTB4_EXEC')?.input_fingerprint !== r('O1_ROUTE_EXEC')?.input_fingerprint);
check('sweep adds a no-execution bridge label despite nested execution', r('O1_UMTB4_EXEC')?.method_execution?.status === 'NOT_EXECUTED_BY_SWEEP' && r('O1_UMTB4_EXEC')?.atomic_review.explicit_model_evaluations === 2);
check('default PLAN leaves outputs unknown without evaluations', r('O2_DEFAULT_PLAN')?.explicit_model_evaluations === 0 && r('O2_DEFAULT_PLAN')?.baseline.model_results[0].execution === 'SCHEMA_VALID_NOT_EXECUTED' && r('O2_DEFAULT_PLAN')?.baseline.invariant_checks[0].state === 'UNKNOWN');
check('mask blocks an invalid projected model', r('O2_MASK_BINDING')?.variants[0].model_results[0].execution === 'BLOCKED_INVALID_VARIANT_MODEL' && r('O2_MASK_BINDING')?.variants[0].invariant_checks[0].state === 'UNKNOWN');
check('removal blocks a missing bound atom', r('O2_REMOVE_BINDING')?.variants[0].model_results[0].execution === 'BLOCKED_MISSING_ATOM' && r('O2_REMOVE_BINDING')?.variants[0].new_model_counterexamples.length === 0);
check('routing can be blocked while explicit nested computation succeeds', r('O2_NO_FRAME_EXEC')?.status === 'BLOCKED_TYPED_FRAME_REQUIRED' && r('O2_NO_FRAME_EXEC')?.selected_classifier_ids.length === 0 && r('O2_NO_FRAME_EXEC')?.method_execution_performed === true);
check('route/atomic object mismatch rejects', error('O2_WRONG_ATOMIC_OBJECT') === 'ATOMIC_OBJECT_MISMATCH');
check('legacy/routing object mismatch rejects', error('O2_WRONG_ROUTE_OBJECT') === 'ROUTING_OBJECT_MISMATCH');
check('determinism is an evaluator precondition beyond shape validation', error('O2_NONDETERMINISTIC_DIRECT') === 'NONDETERMINISTIC_TRANSITION' && r('O2_NONDETERMINISTIC_ROUTE')?.selected_methods[0].input_readiness === 'SCHEMA_VALID_CALLER_MODEL');
check('materialization end is not execution end', r('O3_BUDGET')?.next_variant_offset === null && r('O3_BUDGET')?.execution_complete === false && r('O3_BUDGET')?.next_execution_variant_offset === 15 && r('O3_BUDGET')?.explicit_model_evaluations === 32 && r('O3_BUDGET')?.pending_execution_frontier.length === 2);
check('pending variant checks remain unknown', r('O3_BUDGET')?.variants.at(-1).invariant_checks[0].state === 'UNKNOWN');
check('resumed execution retains the exact variant fingerprint', r('O3_RESUME')?.execution_complete === true && r('O3_RESUME')?.explicit_model_evaluations === 4 && r('O3_RESUME')?.variants[0].variant_fingerprint === r('O3_BUDGET')?.variants.at(-1).variant_fingerprint);
check('changed source revision rejects a prior continuation', error('O3_STALE_SOURCE_RESUME') === 'STALE_ATOMIC_BASE_FINGERPRINT');
const pagedVariants = [...(r('O4_PAGE_ONE')?.variants ?? []), ...(r('O4_PAGE_TWO')?.variants ?? [])];
check('unchanged-plan pages retain full-grid variant semantics', same(pagedVariants, r('O4_FULL_GRID')?.variants));
check('page-local execution can finish before traversal', r('O4_PAGE_ONE')?.execution_complete === true && r('O4_PAGE_ONE')?.next_variant_offset === 2);
check('transform-plan change is accepted with the same baseline fingerprint', byId.get('O4_CHANGED_PLAN_RESUME').returned && r('O4_CHANGED_PLAN_RESUME')?.base_fingerprint === r('O4_PAGE_ONE')?.base_fingerprint);
const ownerValues = variants => variants.map(v => v.atoms.find(a => a.id === 'OWNER-A').value);
const stitchedChanged = [...(r('O4_PAGE_ONE')?.variants ?? []), ...(r('O4_CHANGED_PLAN_RESUME')?.variants ?? [])];
check('changed-plan stitching misses original beta counterexamples', same(ownerValues(r('O4_FULL_GRID')?.variants ?? []), ['alpha','alpha','beta','beta']) && same(ownerValues(stitchedChanged), ['alpha','alpha','alpha','alpha']), {full_grid: ownerValues(r('O4_FULL_GRID')?.variants ?? []), stitched_changed_plan: ownerValues(stitchedChanged)});
const selected = id => r(id)?.selected_methods.map(m => m.method);
check('late required model-ready candidate is excluded by the first-four cap', same(selected('O5_REQUIRED_LAST'), ['metamorphic','ach','relational','partial_order']) && r('O5_REQUIRED_LAST')?.method_candidates.at(-1).method === 'identity' && r('O5_REQUIRED_LAST')?.method_candidates.at(-1).input_readiness === 'SCHEMA_VALID_CALLER_MODEL');
check('same question set reordered selects the required candidate', same(selected('O5_REQUIRED_FIRST'), ['identity','metamorphic','ach','relational']) && same(r('O5_REQUIRED_FIRST')?.required_branches, r('O5_REQUIRED_LAST')?.required_branches), {required_last: selected('O5_REQUIRED_LAST'), required_first: selected('O5_REQUIRED_FIRST')});

const after = await sourceHashes();
check('inspected source files unchanged by this reproduction', same(before, after));
const metadata = {
  schema_version: 'LOCAL_ORCHESTRATION_READBACK_V16.1', started_at: started,
  finished_at: new Date().toISOString(), node_version: process.version, source_head: head,
  source_root: root, git_status_before: statusBefore,
  git_status_after: execFileSync('git', ['status', '--short'], {cwd: root, encoding: 'utf8'}),
  inspected_source_files_unchanged: same(before, after), local_call_count: cases.length,
  expected_error_count: receipts.filter(x => !x.returned).length,
  hosted_calls: 0, source_authentication_claimed: false,
  expected_observations_met: checks.filter(x => x.expectation_met).length,
  expected_observations_total: checks.length,
  interpretation: 'Some met expectations reproduce known orchestration gaps; this is not a clean-product score or hosted parity verdict.'
};
await writeFile(new URL('orchestration-local-readback.json', output), JSON.stringify({metadata, checks, receipts}, null, 2) + '\n');
const evidence = {
  source_head: head, files: before,
  code_evidence: [
    {path: 'lib/methods.mjs', lines: '64-75', observation: 'identity compares declared coordinates. evaluateMethod returns the model fingerprint and bounded receipt.'},
    {path: 'lib/universal-router.mjs', lines: '80-94', observation: 'Questions determine state and insertion order. Models are schema-validated only; the first four method candidates are selected.'},
    {path: 'lib/universal-router.mjs', lines: '99-111', observation: 'Explicit nested atomic review executes independently of question presence. Compatibility binds object IDs and preserves routing fingerprint.'},
    {path: 'lib/review-bridge.mjs', lines: '27', observation: 'Business sweep always adds NOT_EXECUTED_BY_SWEEP bridge metadata, even if nested atomic execution occurred.'},
    {path: 'lib/atomic-review.mjs', lines: '281-305', observation: 'Base fingerprint binds atoms/sources/models/checks, excludes transforms; requested page is materialized; explicit execution shares a 32-evaluation budget.'},
    {path: 'lib/atomic-review.mjs', lines: '337-345', observation: 'Distinct materialization and execution frontiers; execution_complete considers materialized model results.'}
  ]
};
await writeFile(new URL('orchestration-source-evidence.json', output), JSON.stringify(evidence, null, 2) + '\n');
console.log(JSON.stringify({metadata, unmet: checks.filter(x => !x.expectation_met)}, null, 2));
if (checks.some(x => !x.expectation_met)) process.exitCode = 1;
