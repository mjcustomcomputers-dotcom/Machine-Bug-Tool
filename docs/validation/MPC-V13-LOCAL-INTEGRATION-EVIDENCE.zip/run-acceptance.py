import datetime, hashlib, json, os, pathlib, re, subprocess, sys, time

OUT=pathlib.Path(__file__).resolve().parent
ROOT=OUT/'tested-integration'
EVIDENCE=OUT/'evidence';EVIDENCE.mkdir(exist_ok=True)
EXPECTED='a18a040f164e8ad4c47474f77bb10dc5289adac6'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
assert git('rev-parse','HEAD')==EXPECTED and not git('status','--porcelain=v1')
record={'kind':'MPC_V13_LOCAL_INTEGRATION_ACCEPTANCE','tested_commit':EXPECTED,'tested_tree':git('rev-parse','HEAD^{tree}'),'tested_worktree_clean_before':True,'execution_host':'CHATGPT_LINUX_EXECUTOR_NOT_CODEX_CLOUD_OR_WINDOWS','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
env=os.environ.copy();env['XDG_CONFIG_HOME']=str(ROOT/'.sites-runtime/config')
def run(name,args,extra=None):
    target=EVIDENCE/(name+'.stdout.log');err=EVIDENCE/(name+'.stderr.log');start=time.monotonic();command_env=env.copy();command_env.update(extra or {})
    with target.open('w',encoding='utf-8') as stdout,err.open('w',encoding='utf-8') as stderr:
        p=subprocess.run(args,cwd=ROOT,env=command_env,stdout=stdout,stderr=stderr)
    item={'name':name,'command':args,'exit_status':p.returncode,'seconds':time.monotonic()-start,'stdout':target.name,'stderr':err.name,'environment_overrides':extra or {}}
    record['commands'].append(item);(OUT/'acceptance-progress.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(item),flush=True)
    if p.returncode:raise RuntimeError(name+' failed; see actual logs')
    return target.read_text()
try:
    full=run('full-node-tests',['node','--test'])
    counts={}
    for key in ['tests','suites','pass','fail','cancelled','skipped','todo']:
        match=re.search(r'(?:#|ℹ)\s*'+key+r'\s+(\d+)',full)
        if match:counts[key]=int(match.group(1))
    assert counts.get('fail')==0 and counts.get('pass')==counts.get('tests')
    record['test_counts']=counts
    run('build',['npm','run','build'])
    run('receiver-inspect',['node','scripts/receive-mpc-v13.mjs','inspect','--repository',str(ROOT),'--reporting-commit',EXPECTED])
    receive=run('receiver-acceptance',['node','scripts/receive-mpc-v13.mjs','receive','--repository',str(ROOT),'--reporting-commit',EXPECTED,'--destination',str(OUT/'received historical controller Ω')])
    record['receiver']=json.loads(receive)
    notebook=run('notebook',['python3','scripts/run-v13-notebook.py','--output-dir',str(EVIDENCE/'notebook')])
    record['notebook_summary']=json.loads(notebook)
    atlas_env={'MPC_METHOD_ATLAS_DB':str(ROOT/'.sites-runtime/final-acceptance-atlas.sqlite')}
    for command in ['init','status','audit-seed']:
        text=run('atlas-'+command,['node','scripts/method-atlas-cli.mjs',command],atlas_env)
        record['atlas_'+command]=json.loads(text)
    detector=run('detector-benchmark',['node','scripts/benchmark-atomic-method-detector.mjs'],{'MPC_ATLAS_BENCH_RUNS':'500'})
    variation=run('variation-benchmark',['node','scripts/benchmark-atomic-variation-router.mjs'],{'MPC_VARIATION_BENCH_RUNS':'500'})
    record['detector_benchmark']=json.loads(detector);record['variation_benchmark']=json.loads(variation)
    record['tested_worktree_clean_after']=not bool(git('status','--porcelain=v1'))
    assert record['tested_worktree_clean_after']
    record['status']='PASS'
except Exception as error:
    record['status']='FAIL';record['failure']=str(error)
finally:
    record['completed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT/'acceptance.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'status':record['status'],'tests':record.get('test_counts'),'receipt':str(OUT/'acceptance.json')}),flush=True)
if record['status']!='PASS':sys.exit(1)
