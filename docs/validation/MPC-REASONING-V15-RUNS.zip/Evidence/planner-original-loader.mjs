import {registerHooks} from "node:module";
registerHooks({resolve(specifier, context, nextResolve) {
 const resolved = nextResolve(specifier, context);
 return resolved.url === "file:///workspace/scratch/479911d33054/Machine-Bug-Tool-Reasoning/lib/noahs-ark-reasoning.mjs" ? {...resolved,url:"file:///workspace/scratch/479911d33054/evidence/planner-original-324d5c3.mjs",shortCircuit:true} : resolved;
}});
