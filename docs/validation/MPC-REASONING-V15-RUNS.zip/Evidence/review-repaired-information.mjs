import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {compareFiniteDecisions,rankObservationPartitions,validateFiniteInformationPolicy} from '../Machine-Bug-Tool-Reasoning/lib/finite-information-reasoning.mjs';
const folder='/workspace/scratch/479911d33054/evidence/';
const old=JSON.parse(readFileSync(folder+'information-adapter-review-counterexamples.json','utf8'));
const modulePath='/workspace/scratch/479911d33054/Machine-Bug-Tool-Reasoning/lib/finite-information-reasoning.mjs';
const observations=[],projections=[],failures=[];
function collect(value,path){
 if(!value||typeof value!=='object')return;
 if(typeof value.numerator==='string'&&typeof value.denominator==='string'&&typeof value.rounded_value==='number')projections.push({path,...value});
 if(value.exact_expected_utility&&typeof value.expected_utility==='number')projections.push({path,...value.exact_expected_utility,rounded_value:value.expected_utility});
 for(const [key,child] of Object.entries(value))collect(child,path+'/'+key);
}
async function check(id,request,operation,predicate){
 try{const result=await operation(request);collect(result,id);const pass=predicate(result);observations.push({id,pass});if(!pass)failures.push({id,request,result});return result;}
 catch(error){observations.push({id,pass:false,error:error.message});failures.push({id,request,error:error.message});}
}
for(const row of old.source_conflicts)await check('source-conflict:'+row.kind,row.request,rankObservationPartitions,x=>x.selected_option==='NO_OBSERVATION'&&x.ranked_observations.length===0&&x.blocked_observations[0].status==='BLOCKED_SOURCE_ALIGNMENT_UNRESOLVED'&&x.blocked_observations[0].net_evsi===null);
for(const [name,model] of [['positive',old.numeric.model],['negative',old.numeric_negative_variant.model]]){
 for(let i=0;i<40;i++){
  const observation={...old.numeric.observation_template,observation_id:'noop'+i};
  await check('cancellation-rank:'+name+':'+i,{model,observations:[observation]},rankObservationPartitions,x=>x.selected_option==='NO_OBSERVATION'&&x.ranked_observations[0].numerical_accounting.gross_evsi.numerator==='0'&&x.ranked_observations[0].net_evsi===0);
 }
 for(const supplied of [false,true]){
  const policy=model.states.map(s=>({state_id:s.state_id,distribution:[{action_id:'take',probability:1}]}));
  await check('cancellation-compare:'+name+':'+supplied,{model,...(supplied?{policy}:{})},compareFiniteDecisions,x=>x.numerical_accounting.information_gap.numerator==='0'&&(!supplied||x.numerical_accounting.supplied_policy_regret.numerator==='0'));
 }
}
const base=structuredClone(old.source_conflicts[0].request.model);
function fair(reward){const model=structuredClone(base);model.states.forEach(s=>s.payoffs.forEach(p=>{p.utility*=reward;}));return model;}
function reveal(model,observation_id,cost){return {observation_id,actor_id:model.actor_id,access_state:'AVAILABLE',available_before_action:true,cost,source_refs:structuredClone(model.source_refs),partition:model.states.map(s=>({outcome_id:s.state_id,state_ids:[s.state_id]}))};}
const rewards=[Number.MIN_VALUE,3*Number.MIN_VALUE,5*Number.MIN_VALUE,(2**52-1)*Number.MIN_VALUE,2**-1022,2**-1021,1e-20,0.1,1,1e6];
for(let i=0;i<rewards.length;i++)for(const [label,cost] of [['zero',0],['rounded-half',rewards[i]/2],['full',rewards[i]]]){
 const model=fair(rewards[i]),observation=reveal(model,'tiny-reveal',cost),positive=2*cost<rewards[i];
 await check('tiny-value:'+i+':'+label,{model,observations:[observation]},rankObservationPartitions,x=>(BigInt(x.ranked_observations[0].numerical_accounting.net_evsi.numerator)>0n)===positive&&x.selected_option===(positive?'tiny-reveal':'NO_OBSERVATION'));
}
{
 const model=fair(Number.MIN_VALUE);model.states=Array.from({length:4},(_,i)=>({...structuredClone(model.states[i<2?0:1]),state_id:'q'+i,probability:0.25}));
 const full=reveal(model,'z-full',0),coarse={...reveal(model,'a-coarse',0),partition:[{outcome_id:'first',state_ids:['q0']},{outcome_id:'rest',state_ids:['q1','q2','q3']}]};
 await check('underflow-ranking-distinguishes-positive-values',{model,observations:[coarse,full]},rankObservationPartitions,x=>x.selected_option==='z-full'&&x.ranked_observations.every(r=>r.net_evsi===0)&&BigInt(x.ranked_observations[0].numerical_accounting.net_evsi.numerator)>0n);
}
{
 const model=structuredClone(base);model.actions=[{action_id:'a-worse',cost:0},{action_id:'z-better',cost:0}];
 model.states=[1,Number.MIN_VALUE].map((probability,i)=>({state_id:'q'+i,probability,observable_history:[],legal_action_ids:['a-worse','z-better'],payoffs:[{action_id:'a-worse',utility:i?1e6-2**-33:1e6},{action_id:'z-better',utility:1e6}]}));
 const policy=model.states.map(s=>({state_id:s.state_id,distribution:[{action_id:'a-worse',probability:1},{action_id:'z-better',probability:0}]}));
 await check('action-choice-and-regret-below-projection-resolution',{model,policy},compareFiniteDecisions,x=>x.optimal_information_sets[0].chosen_action_id==='z-better'&&x.supplied_policy_regret===0&&BigInt(x.numerical_accounting.supplied_policy_regret.numerator)>0n&&x.optimal_information_sets[0].numerical_accounting.native_maximizers_agree===false);
}
const limit=1e-12,step=2**-92;
for(const excess of [true,false])for(const [label,delta,accepted] of [['inside',limit-step,true],['equal',limit,true],['outside',limit+step,false]])for(const mode of ['prior','policy']){
 const probabilities=excess?[1,delta]:[1-2**-39,2**-39-delta],model=structuredClone(base);
 const policy=model.states.map(s=>({state_id:s.state_id,distribution:['g0','g1'].map((action_id,i)=>({action_id,probability:probabilities[i]}))}));
 if(mode==='prior')model.states.forEach((s,i)=>{s.probability=probabilities[i];});
 const request=mode==='prior'?{model}:{model,policy},fn=mode==='prior'?compareFiniteDecisions:validateFiniteInformationPolicy;
 const id='tolerance:'+mode+':'+excess+':'+label;
 if(accepted)await check(id,request,fn,x=>Boolean(x.status));
 else{
  try{const result=await fn(request);observations.push({id,pass:false});failures.push({id,request,result});}
  catch(error){const pass=error.message.startsWith('PROBABILITIES_MUST_SUM_TO_ONE:');observations.push({id,pass,error:error.message});if(!pass)failures.push({id,request,error:error.message});}
 }
}
const moduleBytes=readFileSync(modulePath);
const report={review:'REPAIRED_FINITE_INFORMATION_INDEPENDENT_CHECK',source_sha256:createHash('sha256').update(moduleBytes).digest('hex'),checks:observations.length,passed:observations.filter(x=>x.pass).length,failed:failures.length,observations,failures,projection_values:projections.length,note:'Local supplied-model checks. Repeated no-op labels are permutation controls, not new method executions or intelligence scores.'};
writeFileSync(folder+'repaired-information-review.json',JSON.stringify(report,null,2)+'\n');
writeFileSync(folder+'repaired-information-projections.json',JSON.stringify(projections)+'\n');
console.log(JSON.stringify({source_sha256:report.source_sha256,checks:report.checks,passed:report.passed,failed:report.failed,projection_values:projections.length,failures:failures.map(({id,error})=>({id,error}))}));
process.exitCode=failures.length?1:0;
