#!/usr/bin/env python3
"""Run the adjacent trusted MPC notebook without installing Jupyter.

Usage: python Run-Offline-Review.py

This standard-library runner accepts no path arguments. It executes the code
cells of MPC-Offline-Review.ipynb in their original order and shared namespace,
with the working directory set to this package. Cell output goes to the console;
the notebook itself is never rewritten. Exceptions retain their traceback and
produce a nonzero exit status. Notebook findings and expected negative fixtures
keep their existing semantics; recorded findings are not rewritten as exceptions.

The reviewed notebook performs no network, plugin, or installation calls.
Its optional WRITE_DERIVED_RESULTS setting remains False by default. This runner
does not override that setting or install anything. Execute only this trusted
notebook; the runner is not a sandbox for arbitrary or modified notebook code.

The runner also checks that the notebook and all declared input JSON files have unchanged
SHA-256 fingerprints after execution. Python execution has been checked in the
cloud Linux environment; actual execution on the user's Windows PC is untested.
"""

import hashlib
import json
import os
import sys
import traceback
from pathlib import Path


NOTEBOOK_NAME = "MPC-Offline-Review.ipynb"
INPUT_NAMES = ("technical_snapshot.json", "audit_records.json", "current_runtime_receipt.json", "current_method_catalog.json", "method_ark_live_inventory.json", "atomic_owner_live_receipt.json", "atomic_core_live_receipt.json", "atomic_deployment_receipt.json")


def fingerprints(paths):
    """Hash the exact local files without changing them."""
    return {
        path: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in paths
    }


def read_code_cells(notebook_path):
    """Return original Python source with its one-based notebook cell number."""
    notebook = json.loads(notebook_path.read_text(encoding="utf-8-sig"))
    if not isinstance(notebook, dict) or notebook.get("nbformat") != 4:
        raise ValueError("The adjacent notebook must be a notebook-format-4 object.")
    cells = notebook.get("cells")
    if not isinstance(cells, list):
        raise ValueError("The adjacent notebook must contain an explicit cells list.")
    code_cells = []
    for cell_number, cell in enumerate(cells, start=1):
        if not isinstance(cell, dict):
            raise ValueError("Notebook cell {} is not an object.".format(cell_number))
        cell_type = cell.get("cell_type")
        if cell_type in ("markdown", "raw"):
            continue
        if cell_type != "code":
            raise ValueError("Notebook cell {} has an invalid type.".format(cell_number))
        source = cell.get("source")
        if isinstance(source, list) and all(isinstance(line, str) for line in source):
            source = "".join(source)
        if not isinstance(source, str):
            raise ValueError("Code cell {} has invalid source text.".format(cell_number))
        code_cells.append((cell_number, source))
    if not code_cells:
        raise ValueError("The adjacent notebook has no code cells to execute.")
    return code_cells


def main():
    if len(sys.argv) != 1:
        print("Usage: python Run-Offline-Review.py (no arguments)", file=sys.stderr)
        return 2

    pack_root = Path(__file__).resolve().parent
    notebook_path = pack_root / NOTEBOOK_NAME
    input_paths = tuple(pack_root / "data" / name for name in INPUT_NAMES)
    checked_paths = (notebook_path,) + input_paths
    initial_hashes = {}
    previous_cwd = Path.cwd()
    active_cell = None
    status = 0

    try:
        for path in checked_paths:
            if not path.is_file():
                raise FileNotFoundError("Required adjacent package file is missing: " + str(path))
        initial_hashes = fingerprints(checked_paths)
        code_cells = read_code_cells(notebook_path)
        os.chdir(pack_root)
        namespace = {"__name__": "__main__"}
        print("MPC offline review: {} code cells".format(len(code_cells)), flush=True)
        print("Package directory:", pack_root, flush=True)

        for ordinal, (cell_number, source) in enumerate(code_cells, start=1):
            active_cell = cell_number
            print("\n--- Code cell {}/{} (notebook cell {}) ---".format(
                ordinal, len(code_cells), cell_number), flush=True)
            label = "{} [notebook cell {}]".format(NOTEBOOK_NAME, cell_number)
            # Assertions stay enabled even if the launcher was given Python's -O.
            code = compile(source, label, "exec", dont_inherit=True, optimize=0)
            exec(code, namespace, namespace)
        active_cell = None

    except KeyboardInterrupt:
        print("\nERROR: Offline review interrupted.", file=sys.stderr, flush=True)
        status = 130
    except BaseException:
        location = "setup" if active_cell is None else "notebook cell {}".format(active_cell)
        print("\nERROR: Offline review failed during " + location + ".",
              file=sys.stderr, flush=True)
        traceback.print_exc()
        status = 1
    finally:
        if initial_hashes:
            try:
                ending_hashes = fingerprints(checked_paths)
                changed = [path.name for path in checked_paths
                           if initial_hashes[path] != ending_hashes[path]]
                if changed:
                    print("ERROR: Package input changed during review: " + ", ".join(changed),
                          file=sys.stderr, flush=True)
                    status = 1
                else:
                    print("\nNotebook and input fingerprints unchanged: {0} of {0}.".format(len(checked_paths)), flush=True)
            except OSError:
                print("ERROR: Could not recheck package input fingerprints.",
                      file=sys.stderr, flush=True)
                traceback.print_exc()
                status = 1
        try:
            os.chdir(previous_cwd)
        except OSError:
            print("ERROR: Could not restore the original working directory.",
                  file=sys.stderr, flush=True)
            traceback.print_exc()
            status = 1

    if status == 0:
        print("Code execution completed; review findings remain as reported above.", flush=True)
    return status


if __name__ == "__main__":
    raise SystemExit(main())
