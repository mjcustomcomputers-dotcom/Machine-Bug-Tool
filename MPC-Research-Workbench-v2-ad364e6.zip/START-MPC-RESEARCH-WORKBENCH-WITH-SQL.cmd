@echo off
setlocal EnableExtensions DisableDelayedExpansion
where node.exe >nul 2>&1
if errorlevel 1 (
 echo ERROR: Node.js 22.13 or newer is required for local SQLite mode.
 echo The offline browser launcher still works without Node.js.
 pause
 exit /b 1
)
node.exe "%~dp0scripts\research-workbench-server.mjs" --root "%~dp0." --open
if errorlevel 1 (
 echo ERROR: MPC Research Workbench local host stopped with an error.
 pause
 exit /b 1
)
endlocal
