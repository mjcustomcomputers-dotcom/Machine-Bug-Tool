@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "MPC_APP=%~dp0MPC-Research-Workbench.html"
if not exist "%MPC_APP%" (
 echo ERROR: MPC-Research-Workbench.html is missing.
 echo Press any key to close this window . . .
 pause >nul
 exit /b 1
)
start "" "%MPC_APP%"
if errorlevel 1 (
 echo ERROR: The default browser could not open MPC Research Workbench.
 echo Press any key to close this window . . .
 pause >nul
 exit /b 1
)
endlocal
